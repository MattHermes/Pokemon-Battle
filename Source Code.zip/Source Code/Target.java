/*
 Author: Matt Hermes
   File: Target.py
Version: 0.310
   Date: 02/08/19
   Desc: Defines the enumerations for the effect targets
     
Change(s):
   --None made
TODO:
   --Nothing   
*/

package pokemonBattle;

public enum Target {
	SELF, OPPONENT, NONE
}
